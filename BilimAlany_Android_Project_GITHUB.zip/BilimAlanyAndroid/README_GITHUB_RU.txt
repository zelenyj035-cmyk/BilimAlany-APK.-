КАК ПОЛУЧИТЬ APK ЧЕРЕЗ GITHUB С ТЕЛЕФОНА

1. Создайте на GitHub новый репозиторий (New repository), например BilimAlany-APK. Можно выбрать Public.
2. В репозитории нажмите Add file -> Upload files.
3. Загрузите ZIP-файл BilimAlany_Android_Project_GITHUB.zip (сам архив, не распаковывая его) и нажмите Commit changes.
4. Откройте Add file -> Create new file.
5. В имени файла укажите точно: .github/workflows/build-apk.yml
6. Откройте файл build-apk.yml из этой папки проекта, скопируйте весь его текст в редактор GitHub и нажмите Commit changes.
7. Откройте вкладку Actions -> Build Bilim Alany APK -> Run workflow -> Run workflow.
8. Дождитесь зелёной галочки. Откройте завершённый запуск, пролистайте вниз до Artifacts и скачайте Bilim-Alany-Android-APK.
9. Распакуйте скачанный ZIP на телефоне. Внутри будет app-debug.apk. Нажмите на него и разрешите установку из этого источника, если Android спросит.

Важно: APK пока отладочный (debug), для личной установки подходит. Не публикуйте его в магазине как релизную сборку.
